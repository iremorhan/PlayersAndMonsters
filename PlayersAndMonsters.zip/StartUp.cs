﻿using System;

namespace PlayersAndMonsters
{
    class StartUp
    {
        static void Main(string[] args)
        {
           
        }
    }
}
